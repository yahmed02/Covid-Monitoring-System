//
//  Covid Monitoring System
//
//  Created on 2020-11-25.
//  Copyright © 2020 Yaseen Ahmed, Rana Hafez, Hana Abouhussein, Mohamed Farghali, Youssef Marwan.
//  All rights reserved.
//  Date of Submission: December 8, 2022

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include <limits> //for cin.ignore()


using namespace std;

/**************************************************************************************
Function: cls
Receives: Nothing
Returns: Nothing
Uses: Nothing
Does: "Clears the screen" for increased readability
***************************************************************************************/
void cls()
{
   cout << string(100, '\n'); //because system("cls") doesn't exist on mac
}


struct Country //Defining a structure as a data type to store country info
{
    string ageGroup[9], numCases[9], dayNum[360], deaths[360], cases[360];
    string name;
    int totalCases = 0, totalDeaths = 0, intervalCases = 0;

};


void displayMainMenu(ifstream &, ifstream &);

void viewCases(Country []);

void readAgeGroups(ifstream &, Country[]);
void readNumerical(ifstream &, Country[]);

void viewMostHit(Country []);
void viewLeastHit(Country []);

int findName(string &, Country[]);

void calcTotalCases(Country []);
void calcTotalDeaths(Country []);

void viewTotalCases(Country[]);
void viewDeathToll(Country[]);

void viewSorted(Country []);

void currentSlope(Country []);



int main(void)
{

    ifstream fin, fin2;

    cout << "-----Welcome to the Covid Monitoring System-----" << endl;
    cout << ("Press enter to continue...");
    getchar();
    displayMainMenu(fin, fin2);

    return 0;
}

/**************************************************************************************
Function: displayMainMenu
Receives: filestreams of both the files used in the program
Returns: Nothing
Uses: Array of courses and the total number of courses
Does: Displays the main menu for the program and calls corresponding
 functions based on user input
***************************************************************************************/

void displayMainMenu(ifstream &fin, ifstream &fin2)
{

    string input, ageInput;

    Country *countries = new Country[195]; /**dynamic allocating memory for an array of structures since some compilers will experience a stack overflow if the memory is allocated statically**/


    readAgeGroups(fin, countries); //calling the function to read the age groups file
    readNumerical(fin2, countries); //calling the function to read the numerical file
    calcTotalDeaths(countries);


    /**Displaying the main menu*/

    do {

        system("cls");
        cout << "-----Main Menu-----" << endl;
        cout << "1) View the new cases per country in selected date interval (Month)" << endl;
        cout << "2) View the total cases till date by country" << endl;
        cout << "3) View death toll till date by country" << endl;
        cout << "4) View the top hit (n) countries" << endl;
        cout << "5) View Data by Age Groups" << endl;
        cout << "6) See the current slope for a country" << endl;
        cout << "7) Quit" << endl;

        cout << "\n==> ";
        getline(cin, input);

        while (input != "1" && input != "2" && input != "3" && input != "4" && input != "5" && input != "6" && input != "7")
        {
            cout << "Invalid Input!... Please try again" << endl;
            cout << "Please make another selection: ";
            cin >> input;
        }

        if (input == "1")
        {
            viewCases(countries);
        }
        else if (input == "2")
        {
            calcTotalCases(countries);
            viewTotalCases(countries);
        }
        else if (input == "3")
        {
            calcTotalDeaths(countries);
            viewDeathToll(countries);
        }
        else if (input == "4")
        {
            calcTotalCases(countries);
            viewSorted(countries);
            readNumerical(fin2, countries); //re-sorting the countries
        }
        else if (input == "5")
        {
            do
            {
                readAgeGroups(fin, countries);
                system("cls");
                cout << "-----Age Menu-----" << endl;
                cout << "1) View the most hit age group in a country" << endl;
                cout << "2) View the least hit age group in a country" << endl;
                cout << "3) Return to main menu" << endl;

                cout << "\n==> ";
                getline(cin, ageInput);

                while (ageInput != "1" && ageInput != "2" && ageInput != "3")
                {
                    cout << "Invalid Input!... Please try again" << endl;
                    cout << "Please make another selection: ";
                    cin >> ageInput;
                }


                if (ageInput == "1")
                {
                    system("cls");
                    viewMostHit(countries);
                }
                else if (ageInput == "2")
                {
                    system("cls");
                    viewLeastHit(countries);
                }


            } while (ageInput != "3");

        }

        else if (input == "6")
        {
            currentSlope(countries);
        }


      } while (input != "7" && input != "Quit" && input != "quit");

}

/**************************************************************************************
Function: viewCases
Receives: Array of countries
Returns: Nothing
Uses: Array of countries
Does: Calculates and displays the cases for a specific country within the
 desired interval
***************************************************************************************/

void viewCases(Country countries[])
{

    int countryNum, difference = 0;
    double month1, month2;
    string month_1, month_2;
    string countryName;

    system("cls");
    cout << "Please input a country: ";
    getline(cin, countryName);
    countryName[0] = toupper(countryName[0]);

    countryNum = findName(countryName, countries);

    while (countryNum == 222 || countryNum > 57)
    {
        cout << "Country input invalid!" << endl;
        cout << "Please input another country name: ";
        cin >> countryName;
        countryName[0] = toupper(countryName[0]);
        countryNum = findName(countryName, countries);
    }


    cout << "Please input the first month as a number: ";
    cin >> month1;

    while (month1 < 1 || month1 > 12 || month1 != static_cast<int>(month1))
    {
        cout << "Invalid input!" << endl;
        cout << "Please input another month as a number: ";
        cin >> month1;
        
    }

    cout << "Please input the second month as a number (greater than month 1): ";
    cin >> month2;

    while (month2 < 1 || month2 > 12 || month2 < month1 || month2 != static_cast<int>(month2))
    {
        cout << "Invalid input!" << endl;
        cout << "Please input another month: ";
        cin >> month2;
    }

    difference = ((30*( (month2-1) - (month1-1) ) ) + 30);


    int startingPosition = (30*(month1-1)) + (360*countryNum);
    int finishingPosition = startingPosition + difference;

    for (int i=startingPosition; i<finishingPosition; i++)
    {
        countries[countryNum].intervalCases += stoi(countries[countryNum].cases[i-(360*countryNum)]);
    }

    switch(static_cast<int>(month1))
    {
        case 1:
            month_1 = "January";
            break;
        case 2:
            month_1 = "February";
            break;
        case 3:
            month_1 = "March";
            break;
        case 4:
            month_1 = "April";
            break;
        case 5:
            month_1 = "May";
            break;
        case 6:
            month_1 = "June";
            break;
        case 7:
            month_1 = "July";
            break;
        case 8:
            month_1 = "August";
            break;
        case 9:
            month_1 = "September";
            break;
        case 10:
            month_1 = "October";
            break;
        case 11:
            month_1 = "November";
            break;
        case 12:
            month_1 = "December";
            break;
    }

    switch(static_cast<int>(month2))
    {
        case 1:
            month_2 = "January";
            break;
        case 2:
            month_2 = "February";
            break;
        case 3:
            month_2 = "March";
            break;
        case 4:
            month_2 = "April";
            break;
        case 5:
            month_2 = "May";
            break;
        case 6:
            month_2 = "June";
            break;
        case 7:
            month_2 = "July";
            break;
        case 8:
            month_2 = "August";
            break;
        case 9:
            month_2 = "September";
            break;
        case 10:
            month_2 = "October";
            break;
        case 11:
            month_2 = "November";
            break;
        case 12:
            month_2 = "December";
            break;
    }

    cout << "The total cases for " << countries[countryNum].name << " between " << month_1 << " and " << month_2 << " are: " << countries[countryNum].intervalCases << endl;

    countries[countryNum].intervalCases = 0;

    cout << "Press enter to return to the main menu...";
    cin.clear(); //clear previous input
    cin.ignore(); //discard previous input
    getchar();

}

/**************************************************************************************
Function: readAgeGroups
Receives: input file stream for the age group file
Returns: Nothing
Uses: Array of countries
Does: reads age group info from csv file
***************************************************************************************/

void readAgeGroups(ifstream &fin, Country countries[])
{

    fin.open("Age Data.csv"); //opening the age data file

    if (fin.fail())
    {
        cout << "Could not open age group file" << endl;
        exit(1);
    }
    else
    {
        while(!fin.eof())
        {
            for (int i=0; i<195; i++)
            {
                for (int x=0; x<9; x++)
                {
                    getline(fin,countries[i].name, ','); //reading country name until ,
                    getline(fin,countries[i].ageGroup[x], ','); //reading age group until ,
                    getline(fin,countries[i].numCases[x], '\n'); //reading num cases until \n

                }

            }

        }

    }


    fin.close(); //closing the file

}

/**************************************************************************************
Function: readNumerical
Receives: input file stream for the cases and deaths data and array of countries
Returns: Nothing
Uses: array of countries
Does: reads cases and deaths for each country from file
***************************************************************************************/

void readNumerical(ifstream &fin2, Country countries[])
{
    fin2.open("Cases and Deaths.csv"); //opening the cases and deaths file

    if (fin2.fail())
    {
        cout << "Could not open age group file" << endl;
        exit(1);
    }
    else
    {
        while (!fin2.eof())
        {
            for (int i=0; i<58; i++)
            {
                for (int x=0; x<360; x++)
                {
                    getline(fin2, countries[i].name, ','); //reading the country names until ,
                    getline(fin2, countries[i].dayNum[x], ','); //reading the number of the day until ,
                    getline(fin2, countries[i].cases[x], ','); //reading the number of cases for that day until ,
                    getline(fin2, countries[i].deaths[x], '\n'); //reading the number of deaths for that day until \n

                }

            }

        }
    }


    fin2.close(); //closing the file

}

/**************************************************************************************
Function: viewMostHit
Receives: Array of countries
Returns: Nothing
Uses: Array of countries
Does: Finds the most hit age group for the desired country and displays it to
 the user
***************************************************************************************/

void viewMostHit(Country countries[])
{
    int countryNum, max = 0;
    string mostHitGroup, countryName;


    cout << "Which country would you like to view: ";
    getline(cin, countryName);
    countryName[0] = toupper(countryName[0]); //capitalizing the first letter of the country name incase the user inputs it as lower case

    countryNum = findName(countryName, countries); //finding the corresponding index for that country

    /**validating user input*/

    while (countryNum == 222)
    {
        cout << "Country input invalid!" << endl;
        cout << "Please input another country name: ";
        cin >> countryName;
        countryName[0] = toupper(countryName[0]);
        countryNum = findName(countryName, countries);
    }


    for(int i = 0; i < 9; i++) //for loop to find the most hit age group
    {

        if(stoi(countries[countryNum].numCases[i]) > max)
        {
            max = stoi(countries[countryNum].numCases[i]);
            mostHitGroup = countries[countryNum].ageGroup[i]; //the "mostHitGroup" is the age group of the index of the most hit group

        }


    }


    system("cls");

    cout << "The most hit age group in " << countries[countryNum].name << " is " << mostHitGroup << " with " << max << " cases" << endl;
    cout << "Press enter to return to the age menu...";

    cin.clear(); //clearing the previous input
    cin.ignore();
    getchar();

}

/**************************************************************************************
Function: viewLeastHit
Receives: Array of countries
Returns: Nothing
Uses: Array of countries
Does: Finds the least hit age group for the desired country and displays it to
 the user
***************************************************************************************/

void viewLeastHit(Country countries[])
{
    int countryNum;
    string countryName;


    cout << "Which country would you like to view: ";
    getline(cin, countryName);
    countryName[0] = toupper(countryName[0]); //capitalizing the first letter of the country name incase the user inputs it as lower case

    countryNum = findName(countryName, countries); //finding the corresponding index for that country

    /**validating user input*/

    while (countryNum == 222)
    {
        cout << "Country input invalid!" << endl;
        cout << "Please input another country name: ";
        cin >> countryName;
        countryName[0] = toupper(countryName[0]);
        countryNum = findName(countryName, countries);
    }

    int min = stoi(countries[countryNum].numCases[0]); //initializing the min to the first age group
    string leastHitGroup = countries[countryNum].ageGroup[0]; //initializing the least hit group to the name of the first age group


    for(int i = 1; i < 9; i++) //for loop to find the min
    {

        if(stoi(countries[countryNum].numCases[i]) < min)
        {
            min = stoi(countries[countryNum].numCases[i]);
            leastHitGroup = countries[countryNum].ageGroup[i];

        }

    }

    system("cls");

    cout << "The least hit age group in " << countries[countryNum].name << " is " << leastHitGroup << " with " << min << " case(s)" << endl;
    cout << "Press enter to return to the age menu...";
    
    cin.clear(); //cleraing the previous input
    cin.ignore();
    getchar();


}

/**************************************************************************************
Function: findName
Receives: countryName and array of country
Returns: the index of the country in the array of countries
Uses: Array of countries
Does: Finds the index of the desired country in the array of countries
***************************************************************************************/

int findName(string & countryName, Country countries[])
{
    int index = 222; //setting a value which will never be returned so it can be used to validate user input

    for (int i=0; i<195; i++)
    {
        if (countryName == countries[i].name)
            index = i;
    }

    return index;

}

/**************************************************************************************
Function: calcTotalCases
Receives: array of countries
Returns: Nothing
Uses: Array of countries
Does: Calculates the total cases for a country till date
***************************************************************************************/

void calcTotalCases(Country countries[])
{
    /**initializing all of the countries' total cases to 0
     so that they don't accumulate everytime the function is called*/

    for (int k=0; k<58; k++)
        countries[k].totalCases = 0;

    /**for loop to calculate the total cases for each country*/

    for (int i=0; i<58; i++)
    {
        for (int j=0; j<360; j++)
        {
            countries[i].totalCases += stoi(countries[i].cases[j]);

        }
    }


}

/**************************************************************************************
Function: calcTotalCases
Receives: array of countries
Returns: Nothing
Uses: Array of countries
Does: Calculates the total deaths for a country till date
***************************************************************************************/

void calcTotalDeaths(Country countries[])
{
    /**initializing all of the countries' total deaths to 0
     so that they don't accumulate everytime the function is called*/

    for (int k=0; k<58; k++)
        countries[k].totalDeaths = 0;

    /**for loop to calculate the total deaths for each country*/

    for (int i=0; i<58; i++)
    {
        for (int j=0; j<360; j++)
        {
            countries[i].totalDeaths += stoi(countries[i].deaths[j]);

        }
    }

}

/**************************************************************************************
Function: viewTotalCases
Receives: array of countries
Returns: Nothing
Uses: Array of countries
Does: displays the total cases for a certain country
***************************************************************************************/

void viewTotalCases(Country countries[])
{

    int countryNum;
    string countryName;

    system("cls");
    cout << "Which country would you like to view: ";
    getline(cin, countryName);
    countryName[0] = toupper(countryName[0]);

    countryNum = findName(countryName, countries);

    /**validating the user input*/

    while (countryNum == 222 || countryNum > 57)
    {
        cout << "Country input invalid!" << endl;
        cout << "Please input another country name: ";
        cin >> countryName;
        countryName[0] = toupper(countryName[0]);
        countryNum = findName(countryName, countries);
    }

    system("cls");
    cout << "The total cases till date for " << countries[countryNum].name << " is: " << countries[countryNum].totalCases << endl;
    cout << "Press enter to return to the main menu...";

    cin.clear(); //clearing the previous input
    cin.ignore();
    getchar();

}

/**************************************************************************************
Function: viewDeathToll
Receives: array of countries
Returns: Nothing
Uses: Array of countries
Does: displays the total deathsfor a certain country
***************************************************************************************/

void viewDeathToll(Country countries[])
{

    int countryNum;
    string countryName;

    system("cls");
    cout << "Which country would you like to view: ";
    getline(cin, countryName);
    countryName[0] = toupper(countryName[0]);

    countryNum = findName(countryName, countries);

    /**validating user input*/

    while (countryNum == 222 || countryNum > 57)
    {
        cout << "Country input invalid!" << endl;
        cout << "Please input another country name: ";
        cin >> countryName;
        countryName[0] = toupper(countryName[0]);
        countryNum = findName(countryName, countries);
    }

    system("cls");
    cout << "The death toll till date for " << countries[countryNum].name << " is: " << countries[countryNum].totalDeaths << endl;
    cout << "Press enter to return to the main menu...";

    cin.clear(); //clearing the previous input
    cin.ignore();
    getchar();

}

/**************************************************************************************
Function: viewSorted
Receives: array of countries
Returns: Nothing
Uses: array of countries
Does: sorts the countries from omst hit cases to least hit using a bubble sort
 algorithm
***************************************************************************************/


void viewSorted(Country countries[])
{

    int sort = 1, temp;
    double n;
    string temp2;

    /**bubble sort algorithm*/

    do
    {
        sort = 0;

        for (int i=0; i<58; i++)
        {
             if (countries[i+1].totalCases > countries[i].totalCases)
             {

                 temp = countries[i+1].totalCases;
                 temp2 = countries[i+1].name;

                 countries[i+1].totalCases = countries[i].totalCases;
                 countries[i+1].name = countries[i].name;

                 countries[i].totalCases = temp;
                 countries[i].name = temp2;
                 sort = 1;

             }

        }

    } while (sort == 1);

    /**asking the user to input the number of countries they would like to view */

    system("cls");
    cout << "Enter the number of countries you would like to view (sorted in terms of number of cases): ";
    cin >> n;
    floor(n);

    /**validating user input*/

    while (int(n) <= 0 || int(n) > 58 || n != static_cast<int>(n))
    {
        cout << "Invalid Input!... Please try again" << endl;
        cout << "Please enter a number greater than 0 and less than or equal to 58: ";
        cin >> n;
    }


    system("cls");
    cout << "The top "<< n << " hit countries: \n\n";

    /**displaying the top hit countries*/

    for (int i=0; i<int(n); i++)
    {
        cout << i+1 << ") " << countries[i].name << ": " << countries[i].totalCases << " cases" << endl;
    }


    cout << endl << endl << "Press enter to return to the main menu...";
    cin.clear(); //clearing the previous input for getchar to eliminate any bugs that may be incurred as a result of improper user input
    cin.ignore();
    getchar();

}

void currentSlope(Country countries[])
{
    int countryNum;
    int x1, y1, x2, y2;
    double slope;
    string countryName;

    system("cls");

    cout << "Which country would you like to view: ";
    getline(cin, countryName);
    countryName[0] = toupper(countryName[0]);

    countryNum = findName(countryName, countries);

    /**validating user input*/

    while (countryNum == 222 || countryNum > 57)
    {
        cout << "Country input invalid!" << endl;
        cout << "Please input another country name: ";
        cin >> countryName;
        countryName[0] = toupper(countryName[0]);
        countryNum = findName(countryName, countries);
    }

    x1 = ((360*countryNum)-11); //the 10th last recorded cases data position
    x2 = ((360 * countryNum) - 1); //the last recorded cases data position

    y1 = stoi(countries[countryNum].cases[x1 - (360*countryNum)]); //the corresponding y value for x1
    y2 = stoi(countries[countryNum].cases[x2 - (360*countryNum)]); //the corresponding y value for x2

    slope = ((y2-y1) / (x2-x1)); //calculating the slope

    /**evaluating the conditions for the slope*/

    if (slope > 0.5)
        cout << "The cases for " << countries[countryNum].name << " are currently increasing" << endl;
    else if (slope < 0.5)
        cout << "The cases for " << countries[countryNum].name << " are currently decreasing" << endl;
    else
        cout << "The cases for " << countries[countryNum].name << " are currently stable" << endl;

    cout << "Press any key to return to the main menu...";
    cin.clear(); //clearing the previous input
    cin.ignore();
    getchar();

}

